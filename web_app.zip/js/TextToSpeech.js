// Simple method
function TextToSpeech(event) {
  event.preventDefault()
  text = document.getElementById("predicted").innerHTML
  console.log(text)
  var msg = new SpeechSynthesisUtterance(text);
  msg.lang = 'en-US';
  window.speechSynthesis.speak(msg);
}


var loadFile = function(event) {
  var reader = new FileReader();
  reader.onload = function(){
    var output = document.getElementById('preview');
    output.classList.remove("d-none")
    output.src = reader.result;
  };
  reader.readAsDataURL(event.target.files[0]); 
};

async function Predict(event) {
  event.preventDefault()
  let formData = new FormData()
  file_tag = document.getElementById("file")
  file = file_tag.files[0]
  formData.append("file", file)
  // formData.append("file", event.target.files[0]);
  formData.append('name', file.name);
  // console.log(file_tag.value)
  // console.log(file)
  // console.log(file.name)
  predicted = await fetch("http://127.0.0.1:5000/file", { method: 'POST', body: formData })
    .then(results => results.json())
  res_tag = document.getElementById("predicted")
  res_tag.innerHTML = predicted.predicted_class_name
  res_tag.value = predicted.predicted_class_name
  speak_tag = document.getElementById("speak")
  speak_tag.classList.remove("visually-hidden")
  console.log(predicted)
  predictedCard = document.getElementById("predicted-card")
  predictedCard.classList.remove("d-none")
  cardResult = document.getElementById("card-result")
  cardResult.innerText = predicted.predicted_class_name
  cardDesc = document.getElementById("card-desc")
  cardDesc.innerText = predicted.summary.summary
  cardButton = document.getElementById("card-wiki-link")
  cardButton.href = predicted.summary.page_url
}

// function TextToSpeech(text) {
//   var msg = new SpeechSynthesisUtterance();
//   var voices = window.speechSynthesis.getVoices();
//   msg.voice = voices[3]; // Note: some voices don't support altering params
//   msg.voiceURI = 'native';
//   msg.volume = 1; // 0 to 1
//   msg.rate = 1; // 0.1 to 10
//   msg.pitch = 2; //0 to 2
//   msg.text = text;
//   msg.lang = 'en-US';

//   msg.onend = function(e) {
//     console.log('Finished in ' + event.elapsedTime + ' seconds.');
//   };
//   setTimeout(() => {
//     speechSynthesis.speak(msg);
//   },1000)
  
// }



// This works only in browser 
// Reference : https://developers.google.com/web/updates/2014/01/Web-apps-that-talk-Introduction-to-the-Speech-Synthesis-API